﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Assignment2.Models
{
    public class AdsCommunity
    {
        public int Id { get; set; }

        public int AdvertisementId { get; set; }

        public Advertisement Advertisement { get; set; }

        public string CommunityId { get; set; }

        public Community Community { get; set; }
    }
}

