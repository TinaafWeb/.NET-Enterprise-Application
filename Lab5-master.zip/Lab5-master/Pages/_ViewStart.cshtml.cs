using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab5.Pages
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
