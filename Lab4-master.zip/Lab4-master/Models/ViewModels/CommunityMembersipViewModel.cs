﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab4.Models.ViewModels
{
    public class CommunityMembersipViewModel
    {
        public string CommunityId { get; set; }
        public string title { get; set; }
        public bool IsMember { get; set; }

    }
}
